#ifndef CONFIG_H
#define CONFIG_H

#ifndef MODE
#define MODE 1
#endif

#define DEBUG_OPT
//int ntt_count = 5;

//#define USE_AES
//#define RANDOMIZED_SIGNING
//#define USE_RDPMC
//#define SERIALIZE_RDC
//#define DBENCH

#endif
